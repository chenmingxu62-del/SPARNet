import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.fft import rfft
from torch_sparse import SparseTensor, matmul

# 从原有的 model.py 导入基础组件
from model import CaNetConv, GraphConvolutionBase, gcn_conv


# ==========================================
# 1. 频域环境编码器 (保持不变，通用)
# ==========================================
class SpectralEnvEncoder(nn.Module):
    def __init__(self, in_dim, out_dim, seq_len):
        super(SpectralEnvEncoder, self).__init__()
        self.seq_len = seq_len
        self.freq_len = seq_len // 2 + 1

        self.freq_mlp = nn.Sequential(
            nn.Linear(in_dim * 2, in_dim),
            nn.ReLU(),
            nn.Linear(in_dim, out_dim)
        )

    def forward(self, h_seq):
        # h_seq: [N, Seq_Len, D]
        # FFT 变换
        specs = torch.fft.rfft(h_seq, dim=1, norm="ortho")

        # 实虚部分离与拼接
        real = specs.real
        imag = specs.imag
        spec_feat = torch.cat([real, imag], dim=-1)

        # 映射
        out = self.freq_mlp(spec_feat)

        # 聚合频率维度
        out = torch.mean(out, dim=1)  # [N, K]
        return out


# ==========================================
# 2. 修正后的 SpectralCaNet
# ==========================================
class SpectralCaNet(nn.Module):
    def __init__(self, d, c, args, device):
        super(SpectralCaNet, self).__init__()
        self.device = device
        self.args = args

        # --- GNN Backbone ---
        self.convs = nn.ModuleList()
        for _ in range(args.num_layers):
            self.convs.append(CaNetConv(
                args.hidden_channels, args.hidden_channels, args.K,
                backbone_type=args.backbone_type, residual=True,
                device=device, variant=args.variant
            ))

        self.fcs = nn.ModuleList()
        self.fcs.append(nn.Linear(d, args.hidden_channels))
        self.fcs.append(nn.Linear(args.hidden_channels, c))

        # --- 环境推断模块 ---
        self.env_enc_time = nn.ModuleList()
        self.env_enc_freq = nn.ModuleList()
        self.fusion = nn.ModuleList()

        # 序列长度 = GNN层数 (历史窗口)
        # 注意：这里我们用的是 hidden states 的历史，
        # 第 i 层推断时，有 i+1 个历史状态 (h0, h1... hi)
        # 为了统一，我们在 SpectralEnvEncoder 里可能需要动态处理，
        # 或者为了简单，我们只用最近的 K 个历史。
        # 这里为了代码简洁，我们假设每层都看它之前的所有历史。

        for i in range(args.num_layers):
            # === 1. 时域/空域分支 ===
            if args.env_type == 'node':
                # Node模式：简单的线性层
                self.env_enc_time.append(nn.Linear(args.hidden_channels, args.K))
            elif args.env_type == 'graph':
                # Graph模式：使用 GCN 提取结构特征作为环境依据
                # 这也是原版 CaNet 的做法
                self.env_enc_time.append(GraphConvolutionBase(args.hidden_channels, args.K, residual=True))
            else:
                raise NotImplementedError

            # === 2. 频域分支 (所有模式通用！) ===
            # 无论是 node 还是 graph 模式，节点特征的演化轨迹都包含频域信息
            # 这里的 seq_len 设为 i+1，因为第 i 层有 i+1 个历史状态
            self.env_enc_freq.append(SpectralEnvEncoder(
                in_dim=args.hidden_channels,
                out_dim=args.K,
                seq_len=i + 1
            ))

            # === 3. 融合层 ===
            self.fusion.append(nn.Linear(args.K * 2, args.K))

        self.act_fn = nn.ReLU()
        self.dropout = args.dropout
        self.num_layers = args.num_layers
        self.tau = args.tau
        self.env_type = args.env_type

    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()
        for fc in self.fcs:
            fc.reset_parameters()

        for enc in self.env_enc_time:
            if hasattr(enc, 'reset_parameters'): enc.reset_parameters()
        for fus in self.fusion:
            if hasattr(fus, 'reset_parameters'): fus.reset_parameters()
        # Freq encoder 内部参数由 PyTorch 初始化

    def forward(self, x, adj, idx=None, training=False):
        self.training = training
        x = F.dropout(x, self.dropout, training=self.training)

        h = self.act_fn(self.fcs[0](x))
        h0 = h.clone()

        # 历史轨迹 Buffer，初始放入 h0
        h_history = [h0]

        reg = 0
        for i, con in enumerate(self.convs):
            h = F.dropout(h, self.dropout, training=self.training)

            # === 环境推断 ===
            # 1. 时域/空域 Logit
            if self.env_type == 'node':
                logit_spatial = self.env_enc_time[i](h)
            else:  # graph 模式
                # 这里的 h0 是原版 CaNet 传入的，代表初始状态
                logit_spatial = self.env_enc_time[i](h, adj, h0)

            # 2. 频域 Logit (所有模式通用)
            # 构造序列张量 [N, Seq_Len, D]
            h_seq = torch.stack(h_history, dim=1)
            logit_spectral = self.env_enc_freq[i](h_seq)

            # 3. 融合
            logit_cat = torch.cat([logit_spatial, logit_spectral], dim=-1)
            logit = self.fusion[i](logit_cat)

            # 训练阶段计算 Gumbel Softmax 和 正则Loss
            if self.training:
                e = F.gumbel_softmax(logit, tau=self.tau, dim=-1)
                reg += self.reg_loss(e, logit)
            else:
                e = F.softmax(logit, dim=-1)

            # GNN 聚合
            h_next = self.act_fn(con(h, adj, e))

            # 更新历史
            h_history.append(h_next.detach())
            h = h_next

        h = F.dropout(h, self.dropout, training=self.training)
        out = self.fcs[-1](h)

        if self.training:
            return out, reg / self.num_layers
        else:
            return out

    # 复用原版辅助函数
    def reg_loss(self, z, logit, logit_0=None):
        log_pi = logit - torch.logsumexp(logit, dim=-1, keepdim=True).repeat(1, logit.size(1))
        return torch.mean(torch.sum(torch.mul(z, log_pi), dim=1))

    def sup_loss_calc(self, y, pred, criterion, args):
        if args.dataset in ('twitch', 'elliptic'):
            if y.shape[1] == 1:
                true_label = F.one_hot(y, y.max() + 1).squeeze(1)
            else:
                true_label = y
            loss = criterion(pred, true_label.squeeze(1).to(torch.float))
        else:
            out = F.log_softmax(pred, dim=1)
            target = y.squeeze(1)
            loss = criterion(out, target)
        return loss

    def loss_compute(self, d, criterion, args):
        logits, reg_loss = self.forward(d.x, d.edge_index, idx=d.train_idx, training=True)
        sup_loss = self.sup_loss_calc(d.y[d.train_idx], logits[d.train_idx], criterion, args)
        loss = sup_loss + args.lamda * reg_loss
        return loss